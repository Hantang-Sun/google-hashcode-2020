import random
sample_size = 30
library_sample_size = 100
magic = 10


def assess_library(days,no_of_books, books_per_day, signup_time,books,bookmaps):
    s = 0
    for i in range (sample_size):
        b = bookmaps[books[random.randint(0,no_of_books-1)]]
        s += b
    mean = s / sample_size

    total = mean * no_of_books

    proportion = min(1, books_per_day * days / no_of_books)

    score = total * proportion / signup_time

    return score

def choose(days,libs,bookmaps):
    select = []
    curr = 0
    while days > (libs[curr].signup_time):
        max_i = 0
        maxscore = 0
        for i in range (curr,library_sample_size):
            index = i % len(libs)
            li =libs[index]
            if li.signup_time < days:
                score = assess_library(days,li.no_of_books, li.books_per_day,li.signup_time, li.books,bookmaps)
                if score > maxscore:
                    maxscore = score
                    max_i = index
        select.append(libs[max_i])
        days -= libs[max_i].signup_time
        libs.remove(libs[max_i])
        if libs == []:
            break
    return select
        

from src.IO import *
from src.Assess import *
from src.Eval import *

file1 = "a_example.txt"
file2 = "b_read_on.txt"
file3 = "c_incunabula.txt"
file4 = "d_tough_choices.txt"
file5 = "e_so_many_books.txt"
file6 = "f_libraries_of_the_world.txt"

files = [file1, file2, file3, file4, file5, file6]

for file in files:
    libs_data: Data = get_data("../tests/"+ file)
    libs = choose(libs_data.days, libs_data.libs, libs_data.books)
    books: [(int, [int])] = select_all(libs, libs_data.books, libs_data.days)
    filename = file.split(".")[0]
    write_result_file("../outputs/"+filename+"result.txt", books)
